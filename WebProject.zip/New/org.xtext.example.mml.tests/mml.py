import pandas as pd
mml_data = pd.read_csv('foo2.csv', sep=';')
print (mml_data)
